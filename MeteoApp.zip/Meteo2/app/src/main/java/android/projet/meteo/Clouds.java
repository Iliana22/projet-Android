package android.projet.meteo;

/**
 * Created by zonia on 06/04/2017.
 */

public class Clouds {
    public double all;
    public double getAll() {
        return all;
    }

    public void setAll(double all) {
        this.all = all;
    }


}
