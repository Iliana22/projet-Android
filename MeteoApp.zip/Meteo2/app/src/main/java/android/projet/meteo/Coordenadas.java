package android.projet.meteo;

/**
 * Created by zonia on 06/04/2017.
 */

public class Coordenadas {
    public double lat;
    public double lng;


    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }



    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }


}
