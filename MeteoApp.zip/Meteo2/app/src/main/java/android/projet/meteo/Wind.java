package android.projet.meteo;

/**
 * Created by zonia on 06/04/2017.
 */

public class Wind {
    public double getDeg() {
        return deg;
    }

    public void setDeg(double deg) {
        this.deg = deg;
    }

    public double getSpeed() {
        return Speed;
    }

    public void setSpeed(double speed) {
        Speed = speed;
    }

    public double deg;
    public double Speed;
}
